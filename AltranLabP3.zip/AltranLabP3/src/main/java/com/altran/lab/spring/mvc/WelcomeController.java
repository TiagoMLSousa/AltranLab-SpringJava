/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.altran.lab.spring.mvc;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author Altran
 */
@Controller
@RequestMapping("/welcome")
public class WelcomeController  {
    
    @RequestMapping(method = RequestMethod.GET)
    public String welcome(ModelMap model) {
        model.addAttribute("message", "Welcome anonymous user!");
        return "welcome";
    }
    
    @RequestMapping(value = "/user?username={username}", method = RequestMethod.GET)
    public ModelAndView welcomeUser(@PathVariable String username) {
        ModelAndView modelAndView = new ModelAndView("welcome");
        modelAndView.addObject("message", "Welcome user! Your username is:");
        modelAndView.addObject("username", username);
        return modelAndView;
    }
}